<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Colaborador extends Model
{
    protected $connection = 'etl';
    protected $table = 'DIM_COLABORADOR';
}
